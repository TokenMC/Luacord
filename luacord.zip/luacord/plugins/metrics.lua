local Metrics = {}
Metrics.__index = Metrics

Metrics.version = "1.0.0"
Metrics.description = "Performance metrics collection"

function Metrics:setup(client)
    self.client = client
    self.metrics = {
        messages_processed = 0,
        commands_executed = 0,
        events_processed = 0,
        api_requests = 0,
        cache_hits = 0,
        cache_misses = 0,
        start_time = os.time()
    }
    
    -- Hook into client events
    client:on("messageCreate", function(message)
        self.metrics.messages_processed = self.metrics.messages_processed + 1
    end)
    
    client:on("INTERACTION_CREATE", function(interaction)
        if interaction.type == 2 then -- Application command
            self.metrics.commands_executed = self.metrics.commands_executed + 1
        end
    end)
    
    client:on("*", function(event)
        self.metrics.events_processed = self.metrics.events_processed + 1
    end)
    
    -- Override _request to track API calls
    local original_request = client._request
    client._request = function(self, method, endpoint, data)
        Metrics.metrics.api_requests = Metrics.metrics.api_requests + 1
        return original_request(self, method, endpoint, data)
    end
    
    -- Add metrics command
    client:registerCommand("metrics", "Show bot metrics", function(client, interaction)
        local uptime = os.time() - self.metrics.start_time
        local days = math.floor(uptime / 86400)
        local hours = math.floor((uptime % 86400) / 3600)
        local minutes = math.floor((uptime % 3600) / 60)
        local seconds = uptime % 60
        
        local cache_stats = client.cache:getStats()
        local hit_rate = cache_stats.hit_rate or 0
        
        local embed = client.Utils.createEmbed()
            :setTitle("📊 Bot Metrics")
            :setColor(0x0099ff)
            :addField("Uptime", string.format("%dd %dh %dm %ds", days, hours, minutes, seconds), true)
            :addField("Messages Processed", tostring(self.metrics.messages_processed), true)
            :addField("Commands Executed", tostring(self.metrics.commands_executed), true)
            :addField("Events Processed", tostring(self.metrics.events_processed), true)
            :addField("API Requests", tostring(self.metrics.api_requests), true)
            :addField("Cache Hit Rate", string.format("%.1f%%", hit_rate), true)
            :setTimestamp(os.date("!%Y-%m-%dT%H:%M:%SZ"))
        
        client:replyToInteraction(interaction.id, interaction.token, {
            type = 4,
            data = {embeds = {embed}}
        })
    end)
    
    client.logger:info("METRICS", "Metrics plugin loaded")
end

function Metrics:cleanup(client)
    client.logger:info("METRICS", "Metrics plugin unloaded")
end

function Metrics:getMetrics()
    return self.metrics
end

return Metrics