local PluginManager = {}
PluginManager.__index = PluginManager

function PluginManager:new(client)
    local self = setmetatable({}, PluginManager)
    self.client = client
    self.plugins = {}
    self.enabled_plugins = {}
    return self
end

function PluginManager:loadPlugin(name, plugin_path)
    if self.enabled_plugins[name] then
        self.client.logger:warn("PLUGIN", "Plugin %s already loaded", name)
        return true
    end
    
    local ok, plugin = pcall(require, plugin_path or "luacord.plugins." .. name)
    if not ok then
        self.client.logger:error("PLUGIN", "Failed to load plugin %s: %s", name, plugin)
        return false
    end
    
    -- Initialize plugin
    if plugin.setup then
        local success, err = pcall(plugin.setup, self.client)
        if not success then
            self.client.logger:error("PLUGIN", "Plugin %s setup failed: %s", name, err)
            return false
        end
    end
    
    self.plugins[name] = plugin
    self.enabled_plugins[name] = true
    
    self.client.logger:info("PLUGIN", "Loaded plugin: %s", name)
    return true
end

function PluginManager:unloadPlugin(name)
    if not self.enabled_plugins[name] then
        self.client.logger:warn("PLUGIN", "Plugin %s not loaded", name)
        return false
    end
    
    local plugin = self.plugins[name]
    
    -- Call cleanup if exists
    if plugin.cleanup then
        pcall(plugin.cleanup, self.client)
    end
    
    self.plugins[name] = nil
    self.enabled_plugins[name] = nil
    
    self.client.logger:info("PLUGIN", "Unloaded plugin: %s", name)
    return true
end

function PluginManager:getPluginInfo(name)
    local plugin = self.plugins[name]
    if not plugin then return nil end
    
    return {
        name = name,
        loaded = true,
        has_setup = type(plugin.setup) == "function",
        has_cleanup = type(plugin.cleanup) == "function",
        version = plugin.version or "1.0.0",
        description = plugin.description or "No description"
    }
end

function PluginManager:getAllPlugins()
    local info = {}
    for name in pairs(self.enabled_plugins) do
        info[name] = self:getPluginInfo(name)
    end
    return info
end

function PluginManager:callHook(hook_name, ...)
    for name, plugin in pairs(self.plugins) do
        if plugin[hook_name] then
            pcall(plugin[hook_name], self.client, ...)
        end
    end
end

return PluginManager