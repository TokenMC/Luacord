local PluginManager = require("luacord.plugins.plugin_manager")
local Metrics = require("luacord.plugins.metrics")
local WebDashboard = require("luacord.plugins.web_dashboard")

return {
    PluginManager = PluginManager,
    Metrics = Metrics,
    WebDashboard = WebDashboard,
    createManager = function(client) return PluginManager:new(client) end
}