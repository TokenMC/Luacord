local LRUCache = {}
LRUCache.__index = LRUCache

function LRUCache:new(max_size, ttl)
    local self = setmetatable({}, LRUCache)
    self.max_size = max_size or 1000
    self.ttl = ttl or 300
    self.data = {}
    self.order = {} -- LRU order tracking
    self.hits = 0
    self.misses = 0
    self.evictions = 0
    return self
end

function LRUCache:set(key, value, custom_ttl)
    local now = os.time()
    local ttl = custom_ttl or self.ttl
    
    -- Evict if needed
    if #self.order >= self.max_size and not self.data[key] then
        self:evict()
    end
    
    -- Update existing or add new
    if self.data[key] then
        self:updateOrder(key)
    else
        table.insert(self.order, 1, key)
    end
    
    self.data[key] = {
        value = value,
        expires = now + ttl,
        created = now,
        accessed = now
    }
end

function LRUCache:get(key)
    local now = os.time()
    local item = self.data[key]
    
    if item then
        if now < item.expires then
            -- Update access time and order
            item.accessed = now
            self:updateOrder(key)
            self.hits = self.hits + 1
            return item.value
        else
            -- Expired, remove
            self:delete(key)
        end
    end
    
    self.misses = self.misses + 1
    return nil
end

function LRUCache:updateOrder(key)
    -- Move key to front (most recently used)
    for i, k in ipairs(self.order) do
        if k == key then
            table.remove(self.order, i)
            table.insert(self.order, 1, key)
            break
        end
    end
end

function LRUCache:evict()
    if #self.order == 0 then return end
    
    -- Remove least recently used
    local lru_key = table.remove(self.order)
    self.data[lru_key] = nil
    self.evictions = self.evictions + 1
end

function LRUCache:delete(key)
    self.data[key] = nil
    for i, k in ipairs(self.order) do
        if k == key then
            table.remove(self.order, i)
            break
        end
    end
end

function LRUCache:cleanup()
    local now = os.time()
    local count = 0
    
    for i = #self.order, 1, -1 do
        local key = self.order[i]
        local item = self.data[key]
        if item and now >= item.expires then
            self:delete(key)
            count = count + 1
        end
    end
    
    return count
end

function LRUCache:getStats()
    self:cleanup()
    local total = self.hits + self.misses
    local hit_rate = total > 0 and (self.hits / total) * 100 or 0
    
    return {
        size = #self.order,
        max_size = self.max_size,
        hits = self.hits,
        misses = self.misses,
        hit_rate = hit_rate,
        evictions = self.evictions,
        memory_usage = self:estimateMemoryUsage()
    }
end

function LRUCache:estimateMemoryUsage()
    local size = 0
    for key, item in pairs(self.data) do
        size = size + #tostring(key) + #tostring(item.value)
    end
    return size
end

function LRUCache:clear()
    self.data = {}
    self.order = {}
    self.hits = 0
    self.misses = 0
    self.evictions = 0
end

return LRUCache