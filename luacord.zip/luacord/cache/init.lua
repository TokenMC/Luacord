local Cache = require("luacord.cache.cache")
local LRUCache = require("luacord.cache.lru_cache")

return {
    Cache = Cache,
    LRUCache = LRUCache,
    create = function(ttl) return Cache:new(ttl) end,
    createLRU = function(max_size, ttl) return LRUCache:new(max_size, ttl) end
}