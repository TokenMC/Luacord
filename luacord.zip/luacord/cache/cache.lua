local Cache = {}
Cache.__index = Cache

function Cache:new(ttl)
    local self = setmetatable({}, Cache)
    self.data = {}
    self.ttl = ttl or 300 -- 5 minutes default
    self.hits = 0
    self.misses = 0
    return self
end

function Cache:set(key, value, custom_ttl)
    local ttl = custom_ttl or self.ttl
    self.data[key] = {
        value = value,
        expires = os.time() + ttl,
        created = os.time()
    }
end

function Cache:get(key)
    local item = self.data[key]
    if item then
        if os.time() < item.expires then
            self.hits = self.hits + 1
            return item.value
        else
            -- Expired, remove it
            self.data[key] = nil
        end
    end
    self.misses = self.misses + 1
    return nil
end

function Cache:delete(key)
    self.data[key] = nil
end

function Cache:clear()
    self.data = {}
    self.hits = 0
    self.misses = 0
end

function Cache:cleanup()
    local now = os.time()
    local count = 0
    for key, item in pairs(self.data) do
        if now >= item.expires then
            self.data[key] = nil
            count = count + 1
        end
    end
    return count
end

function Cache:getStats()
    self:cleanup()
    local total = self.hits + self.misses
    local hit_rate = total > 0 and (self.hits / total) * 100 or 0
    return {
        hits = self.hits,
        misses = self.misses,
        hit_rate = hit_rate,
        size = self:size(),
        ttl = self.ttl
    }
end

function Cache:size()
    local count = 0
    for _ in pairs(self.data) do count = count + 1 end
    return count
end

function Cache:keys()
    local keys = {}
    for key in pairs(self.data) do
        table.insert(keys, key)
    end
    return keys
end

-- Specialized cache methods for Discord objects
function Cache:setUser(user)
    if user and user.id then
        self:set("user_" .. user.id, user, 3600) -- 1 hour for users
    end
end

function Cache:getUser(user_id)
    return self:get("user_" .. user_id)
end

function Cache:setGuild(guild)
    if guild and guild.id then
        self:set("guild_" .. guild.id, guild, 1800) -- 30 minutes for guilds
    end
end

function Cache:getGuild(guild_id)
    return self:get("guild_" .. guild_id)
end

function Cache:setChannel(channel)
    if channel and channel.id then
        self:set("channel_" .. channel.id, channel, 1800) -- 30 minutes for channels
    end
end

function Cache:getChannel(channel_id)
    return self:get("channel_" .. channel_id)
end

return Cache