local ShardManager = {}
ShardManager.__index = ShardManager

function ShardManager:new(total_shards, shard_ids)
    local self = setmetatable({}, ShardManager)
    self.total_shards = total_shards or 1
    self.shard_ids = shard_ids or {0}
    self.shards = {}
    self.session_start_times = {}
    return self
end

function ShardManager:calculateShard(guild_id, total_shards)
    if not guild_id then return 0 end
    return (math.floor(guild_id / 4194304) % total_shards)
end

function ShardManager:getShardForGuild(guild_id)
    return self:calculateShard(guild_id, self.total_shards)
end

function ShardManager:registerShard(shard_id, shard_instance)
    self.shards[shard_id] = shard_instance
    self.session_start_times[shard_id] = os.time()
end

function ShardManager:broadcast(op, data)
    for _, shard in pairs(self.shards) do
        shard:sendGateway({op = op, d = data})
    end
end

function ShardManager:getShardStats()
    local stats = {
        total_shards = self.total_shards,
        active_shards = 0,
        sessions = {}
    }
    
    for shard_id, shard in pairs(self.shards) do
        if shard.connected then
            stats.active_shards = stats.active_shards + 1
        end
        stats.sessions[shard_id] = {
            session_id = shard.session_id,
            sequence = shard.sequence,
            connected = shard.connected,
            uptime = os.time() - (self.session_start_times[shard_id] or os.time())
        }
    end
    
    return stats
end

return ShardManager