local ConnectionManager = {}
ConnectionManager.__index = ConnectionManager

function ConnectionManager:new(client, shard_id, total_shards)
    local self = setmetatable({}, ConnectionManager)
    self.client = client
    self.shard_id = shard_id or 0
    self.total_shards = total_shards or 1
    self.sequence = nil
    self.session_id = nil
    self.connected = false
    self.reconnect_attempts = 0
    self.max_reconnect_attempts = 10
    self.last_heartbeat_ack = true
    return self
end

function ConnectionManager:connect()
    local ws = require("websocket.client").sync
    self.ws = ws()
    
    local gateway = self.client.resume_gateway_url or self.client.gateway
    self.ws:connect(gateway)
    
    -- Receive Hello
    local hello_msg = self.ws:receive()
    local hello = json.decode(hello_msg)
    self.heartbeat_interval = hello.d.heartbeat_interval / 1000
    
    -- Send Identify or Resume
    if self.session_id then
        self:sendGateway({
            op = 6,
            d = {
                token = self.client.token,
                session_id = self.session_id,
                seq = self.sequence or 0
            }
        })
        self.client.logger:info("GATEWAY", "Shard %d resuming session", self.shard_id)
    else
        self:sendGateway({
            op = 2,
            d = {
                token = self.client.token,
                intents = self.client.intents,
                properties = {
                    ["$os"] = "linux",
                    ["$browser"] = "luacord",
                    ["$device"] = "luacord"
                },
                shard = {self.shard_id, self.total_shards},
                presence = self.client.presence
            }
        })
    end
    
    self.connected = true
    self.reconnect_attempts = 0
    self.client.logger:info("GATEWAY", "Shard %d connected successfully", self.shard_id)
end

function ConnectionManager:reconnect()
    self.reconnect_attempts = self.reconnect_attempts + 1
    local delay = self:calculateBackoff(self.reconnect_attempts)
    
    self.client.logger:warn("GATEWAY", 
        "Shard %d reconnecting (attempt %d/%d) in %ds", 
        self.shard_id, self.reconnect_attempts, self.max_reconnect_attempts, delay)
    
    self.client.async_handler:set_timeout(function()
        local success, err = pcall(function() self:connect() end)
        if not success then
            self.client.logger:error("GATEWAY", "Shard %d reconnect failed: %s", self.shard_id, err)
            if self.reconnect_attempts < self.max_reconnect_attempts then
                self:reconnect()
            else
                self.client.logger:error("GATEWAY", "Shard %d giving up after %d attempts", 
                    self.shard_id, self.max_reconnect_attempts)
            end
        end
    end, delay)
end

function ConnectionManager:calculateBackoff(attempt)
    -- Exponential backoff with jitter: min(2^attempt * 1s, 60s) + random(0, 1s)
    local base_delay = math.min(math.pow(2, attempt), 60)
    local jitter = math.random()
    return base_delay + jitter
end

function ConnectionManager:sendGateway(data)
    if self.ws and self.connected then
        self.ws:send(json.encode(data))
    end
end

function ConnectionManager:validateSession()
    if not self.session_id or not self.sequence then
        return false
    end
    
    -- Check if session is likely still valid (within reasonable time)
    local session_age = os.time() - (self.session_start_time or 0)
    return session_age < 3600 -- Sessions typically valid for ~1 hour
end

return ConnectionManager