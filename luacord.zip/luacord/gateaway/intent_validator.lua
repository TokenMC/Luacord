local IntentValidator = {}
IntentValidator.__index = IntentValidator

function IntentValidator:new()
    local self = setmetatable({}, IntentValidator)
    self.privileged_intents = {
        "guild_members",
        "guild_presences", 
        "message_content"
    }
    return self
end

function IntentValidator:validate(intents, options)
    options = options or {}
    local errors = {}
    local warnings = {}
    
    -- Check for privileged intents without authorization
    for _, intent in ipairs(self.privileged_intents) do
        if intents[intent] and not options.privileged_intents_authorized then
            table.insert(errors, string.format(
                "Privileged intent '%s' requires authorization in Discord Developer Portal",
                intent
            ))
        end
    end
    
    -- Check intent combinations that might cause issues
    if intents.guild_members and not intents.guilds then
        table.insert(warnings, "guild_members intent typically requires guilds intent")
    end
    
    if intents.message_content and not (intents.guild_messages or intents.direct_messages) then
        table.insert(warnings, "message_content intent without message intents may not receive messages")
    end
    
    -- Validate intent values are within range
    local calculated = self:calculateBitmask(intents)
    if calculated > 0x7FFFF then -- Max valid intent value
        table.insert(errors, "Intent bitmask exceeds maximum value")
    end
    
    return {
        valid = #errors == 0,
        errors = errors,
        warnings = warnings,
        bitmask = calculated
    }
end

function IntentValidator:calculateBitmask(intent_table)
    local intent_values = {
        guilds = 1 << 0,
        guild_members = 1 << 1,
        guild_bans = 1 << 2,
        guild_emojis = 1 << 3,
        guild_integrations = 1 << 4,
        guild_webhooks = 1 << 5,
        guild_invites = 1 << 6,
        guild_voice_states = 1 << 7,
        guild_presences = 1 << 8,
        guild_messages = 1 << 9,
        guild_message_reactions = 1 << 10,
        guild_message_typing = 1 << 11,
        direct_messages = 1 << 12,
        direct_message_reactions = 1 << 13,
        direct_message_typing = 1 << 14,
        message_content = 1 << 15,
        guild_scheduled_events = 1 << 16,
        auto_moderation_configuration = 1 << 17,
        auto_moderation_execution = 1 << 18
    }
    
    local bitmask = 0
    for intent, enabled in pairs(intent_table) do
        if enabled and intent_values[intent] then
            bitmask = bitmask | intent_values[intent]
        end
    end
    
    return bitmask
end

function IntentValidator:getRecommendedIntents(bot_type)
    -- bot_type: "moderation", "music", "utility", "logging"
    local recommendations = {
        moderation = {"guilds", "guild_members", "guild_bans", "guild_messages", "message_content"},
        music = {"guilds", "guild_voice_states", "guild_messages"},
        utility = {"guilds", "guild_messages", "message_content"},
        logging = {"guilds", "guild_messages", "guild_message_reactions", "direct_messages"}
    }
    
    return recommendations[bot_type] or {"guilds", "guild_messages"}
end

return IntentValidator