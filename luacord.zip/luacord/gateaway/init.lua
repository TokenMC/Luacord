local ShardManager = require("luacord.gateway.shard_manager")
local ConnectionManager = require("luacord.gateway.connection_manager")
local IntentValidator = require("luacord.gateway.intent_validator")

return {
    ShardManager = ShardManager,
    ConnectionManager = ConnectionManager,
    IntentValidator = IntentValidator,
    validateIntents = function(...) return IntentValidator:validate(...) end,
    calculateShard = function(...) return ShardManager:calculateShard(...) end
}