local CogManager = {}
CogManager.__index = CogManager

function CogManager:new(client)
    local self = setmetatable({}, CogManager)
    self.client = client
    self.cogs = {}
    self.dependencies = {}
    self.loaded_cogs = {}
    return self
end

function CogManager:loadCog(name, cog_path)
    if self.loaded_cogs[name] then
        self.client.logger:warn("COG", "Cog %s already loaded", name)
        return true
    end
    
    local ok, cog = pcall(require, cog_path or "luacord.cogs." .. name)
    if not ok then
        self.client.logger:error("COG", "Failed to load cog %s: %s", name, cog)
        return false
    end
    
    -- Check dependencies
    if cog.dependencies then
        for _, dep in ipairs(cog.dependencies) do
            if not self.loaded_cogs[dep] then
                self.client.logger:warn("COG", "Cog %s requires %s, loading...", name, dep)
                if not self:loadCog(dep) then
                    self.client.logger:error("COG", "Missing dependency %s for cog %s", dep, name)
                    return false
                end
            end
        end
    end
    
    -- Initialize cog
    if cog.setup then
        local success, err = pcall(cog.setup, self.client)
        if not success then
            self.client.logger:error("COG", "Cog %s setup failed: %s", name, err)
            return false
        end
    end
    
    self.cogs[name] = cog
    self.loaded_cogs[name] = true
    
    -- Register commands if any
    if cog.commands then
        for cmd_name, cmd_data in pairs(cog.commands) do
            self.client.commands:registerCommand(
                cmd_name,
                cmd_data.description,
                cmd_data.options,
                cmd_data.callback,
                name
            )
        end
    end
    
    -- Register events if any
    if cog.events then
        for event, handler in pairs(cog.events) do
            self.client:on(event, handler)
        end
    end
    
    self.client.logger:info("COG", "Loaded cog: %s", name)
    return true
end

function CogManager:unloadCog(name)
    if not self.loaded_cogs[name] then
        self.client.logger:warn("COG", "Cog %s not loaded", name)
        return false
    end
    
    local cog = self.cogs[name]
    
    -- Call cleanup if exists
    if cog.cleanup then
        pcall(cog.cleanup, self.client)
    end
    
    -- Unregister commands
    self.client.commands:unregisterCog(name)
    
    -- Note: Event unregistration would require tracking which events were registered
    
    self.cogs[name] = nil
    self.loaded_cogs[name] = nil
    
    self.client.logger:info("COG", "Unloaded cog: %s")
    return true
end

function CogManager:reloadCog(name)
    self:unloadCog(name)
    return self:loadCog(name)
end

function CogManager:getCogInfo(name)
    local cog = self.cogs[name]
    if not cog then return nil end
    
    return {
        name = name,
        loaded = true,
        has_setup = type(cog.setup) == "function",
        has_cleanup = type(cog.cleanup) == "function",
        command_count = cog.commands and #cog.commands or 0,
        event_count = cog.events and #cog.events or 0,
        dependencies = cog.dependencies or {}
    }
end

function CogManager:getAllCogs()
    local info = {}
    for name in pairs(self.loaded_cogs) do
        info[name] = self:getCogInfo(name)
    end
    return info
end

return CogManager