local CooldownManager = {}
CooldownManager.__index = CooldownManager

function CooldownManager:new()
    local self = setmetatable({}, CooldownManager)
    self.cooldowns = {}
    self.buckets = {} -- "user", "guild", "channel", "global"
    return self
end

function CooldownManager:setCooldown(command, bucket_type, identifier, duration)
    local bucket_key = command .. ":" .. bucket_type .. ":" .. (identifier or "global")
    local expires = os.time() + duration
    
    if not self.cooldowns[bucket_key] then
        self.cooldowns[bucket_key] = {}
    end
    
    self.cooldowns[bucket_key].expires = expires
    self.cooldowns[bucket_key].hits = (self.cooldowns[bucket_key].hits or 0) + 1
end

function CooldownManager:checkCooldown(command, bucket_type, identifier)
    local bucket_key = command .. ":" .. bucket_type .. ":" .. (identifier or "global")
    local cooldown = self.cooldowns[bucket_key]
    
    if not cooldown then return 0 end
    
    local remaining = cooldown.expires - os.time()
    return math.max(0, remaining)
end

function CooldownManager:cleanup()
    local now = os.time()
    local removed = 0
    
    for key, cooldown in pairs(self.cooldowns) do
        if now >= cooldown.expires then
            self.cooldowns[key] = nil
            removed = removed + 1
        end
    end
    
    return removed
end

function CooldownManager:getStats()
    self:cleanup()
    
    local stats = {
        active_cooldowns = 0,
        buckets = {},
        total_hits = 0
    }
    
    for key, cooldown in pairs(self.cooldowns) do
        stats.active_cooldowns = stats.active_cooldowns + 1
        stats.total_hits = stats.total_hits + (cooldown.hits or 0)
        
        local bucket_type = key:match(":(%w+):")
        stats.buckets[bucket_type] = (stats.buckets[bucket_type] or 0) + 1
    end
    
    return stats
end

return CooldownManager