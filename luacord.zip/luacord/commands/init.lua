local CommandSystem = require("luacord.commands.command_system")
local CooldownManager = require("luacord.commands.cooldown_manager")
local CogManager = require("luacord.commands.cog_manager")

return {
    CommandSystem = CommandSystem,
    CooldownManager = CooldownManager,
    CogManager = CogManager,
    createSystem = function(client) return CommandSystem:new(client) end,
    createCooldownManager = function() return CooldownManager:new() end,
    createCogManager = function(client) return CogManager:new(client) end
}