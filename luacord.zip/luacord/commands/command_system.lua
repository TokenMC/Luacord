local CommandSystem = {}
CommandSystem.__index = CommandSystem

function CommandSystem:new(client)
    local self = setmetatable({}, CommandSystem)
    self.client = client
    self.commands = {}
    self.cogs = {}
    self.namespaces = {}
    return self
end

-- Register command with namespace support
function CommandSystem:registerCommand(name, description, options, callback, namespace)
    if type(options) == "function" then
        callback = options
        options = {}
        namespace = callback
        callback = nil
    end
    
    local command_data = {
        callback = callback,
        description = description,
        options = options or {},
        namespace = namespace or "global",
        name = name
    }
    
    local full_name = namespace and namespace .. ":" .. name or name
    self.commands[full_name] = command_data
    
    -- Register namespace
    if namespace and not self.namespaces[namespace] then
        self.namespaces[namespace] = true
    end
    
    return full_name
end

-- Register a complete cog
function CommandSystem:registerCog(name, cog_table)
    self.cogs[name] = {
        table = cog_table,
        commands = {}
    }
    
    -- Auto-register cog commands
    if cog_table.commands then
        for cmd_name, cmd_data in pairs(cog_table.commands) do
            local full_name = self:registerCommand(
                cmd_name,
                cmd_data.description,
                cmd_data.options,
                cmd_data.callback,
                name
            )
            self.cogs[name].commands[full_name] = true
        end
    end
    
    -- Call cog setup if exists
    if cog_table.setup then
        pcall(cog_table.setup, self.client)
    end
    
    return name
end

-- Auto-sync commands with Discord
function CommandSystem:syncCommands(scope, guild_id)
    scope = scope or "global" -- "global" or "guild"
    
    local commands_to_sync = {}
    for full_name, cmd_data in pairs(self.commands) do
        if scope == "global" or (scope == "guild" and cmd_data.namespace ~= "global") then
            local discord_cmd = {
                name = cmd_data.name,
                description = cmd_data.description,
                options = cmd_data.options,
                type = 1 -- Chat input
            }
            table.insert(commands_to_sync, discord_cmd)
        end
    end
    
    local endpoint = scope == "global" 
        and "/applications/@me/commands"
        or "/applications/@me/guilds/" .. guild_id .. "/commands"
    
    -- Clear existing commands first
    local existing_cmds = self.client:_request("GET", endpoint) or {}
    for _, cmd in ipairs(existing_cmds) do
        self.client:_request("DELETE", endpoint .. "/" .. cmd.id)
    end
    
    -- Register new commands
    for _, cmd in ipairs(commands_to_sync) do
        local result = self.client:_request("POST", endpoint, cmd)
        if result then
            print("✅ Registered command: " .. cmd.name)
        else
            print("❌ Failed to register command: " .. cmd.name)
        end
    end
    
    return #commands_to_sync
end

-- Handle interaction
function CommandSystem:handleInteraction(interaction)
    if interaction.type == 2 then -- Application command
        local command_name = interaction.data.name
        local full_name = command_name
        
        -- Check for namespaced commands
        if interaction.data.options and #interaction.data.options > 0 then
            local first_option = interaction.data.options[1]
            if first_option.type == 1 then -- Subcommand
                full_name = command_name .. ":" .. first_option.name
            end
        end
        
        local cmd = self.commands[full_name] or self.commands[command_name]
        if cmd and cmd.callback then
            pcall(cmd.callback, self.client, interaction)
            return true
        end
    end
    
    return false
end

-- Get command statistics
function CommandSystem:getStats()
    local stats = {
        total_commands = 0,
        namespaces = 0,
        cogs = 0,
        commands_by_namespace = {}
    }
    
    for full_name, cmd in pairs(self.commands) do
        stats.total_commands = stats.total_commands + 1
        local ns = cmd.namespace
        stats.commands_by_namespace[ns] = (stats.commands_by_namespace[ns] or 0) + 1
    end
    
    stats.namespaces = #self:getNamespaces()
    stats.cogs = #self:getCogs()
    
    return stats
end

function CommandSystem:getNamespaces()
    local namespaces = {}
    for ns in pairs(self.namespaces) do
        table.insert(namespaces, ns)
    end
    return namespaces
end

function CommandSystem:getCogs()
    local cog_names = {}
    for name in pairs(self.cogs) do
        table.insert(cog_names, name)
    end
    return cog_names
end

-- Unregister commands from a cog
function CommandSystem:unregisterCog(name)
    local cog = self.cogs[name]
    if cog then
        for full_name in pairs(cog.commands) do
            self.commands[full_name] = nil
        end
        self.cogs[name] = nil
        self.namespaces[name] = nil
    end
end

return CommandSystem