local AsyncHandler = require("luacord.async.async_handler")
local Promise = require("luacord.async.promise")
local CoroutineHTTP = require("luacord.async.coroutine_http")

return {
    AsyncHandler = AsyncHandler,
    Promise = Promise,
    CoroutineHTTP = CoroutineHTTP,
    createHandler = function() return AsyncHandler:new() end,
    createPromise = function(...) return Promise:new(...) end
}