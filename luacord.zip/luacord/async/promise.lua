local Promise = {}
Promise.__index = Promise

function Promise:new(executor)
    local self = setmetatable({}, Promise)
    self.state = "pending" -- pending, fulfilled, rejected
    self.value = nil
    self.reason = nil
    self.on_fulfilled = {}
    self.on_rejected = {}
    
    if executor then
        executor(
            function(value) self:resolve(value) end,
            function(reason) self:reject(reason) end
        )
    end
    
    return self
end

function Promise:resolve(value)
    if self.state ~= "pending" then return end
    
    if value and type(value) == "table" and getmetatable(value) == Promise then
        value:then_(function(val) self:resolve(val) end, function(err) self:reject(err) end)
        return
    end
    
    self.state = "fulfilled"
    self.value = value
    
    for _, callback in ipairs(self.on_fulfilled) do
        self.client.async_handler:queue_callback(function()
            pcall(callback, value)
        end)
    end
    
    self.on_fulfilled = {}
    self.on_rejected = {}
end

function Promise:reject(reason)
    if self.state ~= "pending" then return end
    
    self.state = "rejected"
    self.reason = reason
    
    for _, callback in ipairs(self.on_rejected) do
        self.client.async_handler:queue_callback(function()
            pcall(callback, reason)
        end)
    end
    
    self.on_fulfilled = {}
    self.on_rejected = {}
end

function Promise:then_(on_fulfilled, on_rejected)
    local next_promise = Promise:new()
    
    local function handle_fulfilled(value)
        if type(on_fulfilled) == "function" then
            local success, result = pcall(on_fulfilled, value)
            if success then
                next_promise:resolve(result)
            else
                next_promise:reject(result)
            end
        else
            next_promise:resolve(value)
        end
    end
    
    local function handle_rejected(reason)
        if type(on_rejected) == "function" then
            local success, result = pcall(on_rejected, reason)
            if success then
                next_promise:resolve(result)
            else
                next_promise:reject(result)
            end
        else
            next_promise:reject(reason)
        end
    end
    
    if self.state == "fulfilled" then
        self.client.async_handler:queue_callback(function()
            handle_fulfilled(self.value)
        end)
    elseif self.state == "rejected" then
        self.client.async_handler:queue_callback(function()
            handle_rejected(self.reason)
        end)
    else
        table.insert(self.on_fulfilled, handle_fulfilled)
        table.insert(self.on_rejected, handle_rejected)
    end
    
    return next_promise
end

function Promise:catch(on_rejected)
    return self:then_(nil, on_rejected)
end

function Promise:finally(on_finally)
    return self:then_(
        function(value)
            on_finally()
            return value
        end,
        function(reason)
            on_finally()
            error(reason)
        end
    )
end

-- Static methods
function Promise.resolve(value)
    return Promise:new(function(resolve) resolve(value) end)
end

function Promise.reject(reason)
    return Promise:new(function(_, reject) reject(reason) end)
end

function Promise.all(promises)
    return Promise:new(function(resolve, reject)
        local results = {}
        local completed = 0
        
        if #promises == 0 then
            resolve(results)
            return
        end
        
        for i, promise in ipairs(promises) do
            promise:then_(function(value)
                results[i] = value
                completed = completed + 1
                if completed == #promises then
                    resolve(results)
                end
            end, reject)
        end
    end)
end

function Promise.race(promises)
    return Promise:new(function(resolve, reject)
        for _, promise in ipairs(promises) do
            promise:then_(resolve, reject)
        end
    end)
end

return Promise