local AsyncHandler = {}
AsyncHandler.__index = AsyncHandler

function AsyncHandler:new()
    local self = setmetatable({}, AsyncHandler)
    self.timers = {}
    self.callbacks = {}
    self.running = false
    return self
end

-- Simple event loop implementation
function AsyncHandler:run()
    self.running = true
    while self.running do
        self:_process_timers()
        self:_process_callbacks()
        -- Small sleep to prevent CPU spinning
        self:_sleep(0.01)
    end
end

function AsyncHandler:stop()
    self.running = false
end

function AsyncHandler:set_timeout(callback, delay)
    local timer = {
        callback = callback,
        execute_at = os.time() + delay,
        id = #self.timers + 1
    }
    table.insert(self.timers, timer)
    return timer.id
end

function AsyncHandler:set_interval(callback, interval)
    local timer = {
        callback = callback,
        interval = interval,
        execute_at = os.time() + interval,
        id = #self.timers + 1
    }
    table.insert(self.timers, timer)
    return timer.id
end

function AsyncHandler:clear_timer(timer_id)
    for i, timer in ipairs(self.timers) do
        if timer.id == timer_id then
            table.remove(self.timers, i)
            break
        end
    end
end

function AsyncHandler:queue_callback(callback)
    table.insert(self.callbacks, callback)
end

function AsyncHandler:_process_timers()
    local now = os.time()
    for i = #self.timers, 1, -1 do
        local timer = self.timers[i]
        if now >= timer.execute_at then
            pcall(timer.callback)
            if timer.interval then
                -- Interval timer, reschedule
                timer.execute_at = now + timer.interval
            else
                -- Timeout timer, remove
                table.remove(self.timers, i)
            end
        end
    end
end

function AsyncHandler:_process_callbacks()
    while #self.callbacks > 0 do
        local callback = table.remove(self.callbacks, 1)
        pcall(callback)
    end
end

function AsyncHandler:_sleep(seconds)
    local ok, socket = pcall(require, "socket")
    if ok and socket.sleep then
        socket.sleep(seconds)
    else
        -- Fallback to busy wait for small intervals
        local start = os.time()
        while os.time() - start < seconds do
            -- Busy wait
        end
    end
end

return AsyncHandler