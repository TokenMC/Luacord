local CoroutineHTTP = {}
CoroutineHTTP.__index = CoroutineHTTP

function CoroutineHTTP:new(client)
    local self = setmetatable({}, CoroutineHTTP)
    self.client = client
    self.pending_requests = {}
    self.active_coroutines = {}
    return self
end

function CoroutineHTTP:request(method, endpoint, data)
    local co = coroutine.running()
    if not co then
        -- Not in coroutine, fallback to sync
        return self.client:_request(method, endpoint, data)
    end
    
    local request_id = #self.pending_requests + 1
    self.pending_requests[request_id] = {
        coroutine = co,
        method = method,
        endpoint = endpoint,
        data = data
    }
    
    -- Execute the request asynchronously
    self.client.async_handler:queue_callback(function()
        self:_executeRequest(request_id)
    end)
    
    return coroutine.yield()
end

function CoroutineHTTP:_executeRequest(request_id)
    local request = self.pending_requests[request_id]
    if not request then return end
    
    local success, result, headers, code = pcall(function()
        return self.client:_request(request.method, request.endpoint, request.data)
    end)
    
    self.active_coroutines[request.coroutine] = true
    
    local resume_success, resume_error = coroutine.resume(request.coroutine, {
        success = success,
        result = result,
        headers = headers,
        code = code
    })
    
    if not resume_success then
        self.client.logger:error("COROUTINE", "Failed to resume coroutine: %s", resume_error)
    end
    
    self.active_coroutines[request.coroutine] = nil
    self.pending_requests[request_id] = nil
end

function CoroutineHTTP:wrap(fn)
    return function(...)
        local args = {...}
        return self.client.async_handler:queue_callback(function()
            local co = coroutine.create(fn)
            local success, result = coroutine.resume(co, unpack(args))
            if not success then
                self.client.logger:error("COROUTINE", "Coroutine error: %s", result)
            end
        end)
    end
end

function CoroutineHTTP:getStats()
    return {
        pending_requests = #self.pending_requests,
        active_coroutines = #self.active_coroutines
    }
end

return CoroutineHTTP