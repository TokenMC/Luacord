local RotatingLogger = {}
RotatingLogger.__index = RotatingLogger

function RotatingLogger:new(options)
    options = options or {}
    local self = setmetatable({}, RotatingLogger)
    
    self.level = options.level or Logging.LEVELS.INFO
    self.max_size = options.max_size or 10 * 1024 * 1024 -- 10MB
    self.max_files = options.max_files or 5
    self.filename = options.filename or "luacord.log"
    self.backup_dir = options.backup_dir or "logs"
    self.colors = options.colors ~= false
    self.timestamps = options.timestamps ~= false
    
    self.current_size = 0
    self.hooks = options.hooks or {}
    
    -- Ensure backup directory exists
    os.execute("mkdir -p " .. self.backup_dir)
    
    -- Get initial file size
    local file = io.open(self.filename, "r")
    if file then
        self.current_size = file:seek("end")
        file:close()
    end
    
    return self
end

function RotatingLogger:log(level, module, message, ...)
    if level < self.level then return end
    
    -- Format message
    if select('#', ...) > 0 then
        message = string.format(message, ...)
    end
    
    local timestamp = self.timestamps and os.date("%Y-%m-%d %H:%M:%S") or ""
    local level_name = self:_levelToName(level)
    local log_entry = string.format("[%s] [%s] [%s] %s\n", 
        timestamp, level_name, module or "GLOBAL", message)
    
    -- Check if rotation is needed
    if self.current_size + #log_entry > self.max_size then
        self:rotate()
    end
    
    -- Write to file
    local file = io.open(self.filename, "a")
    if file then
        file:write(log_entry)
        self.current_size = self.current_size + #log_entry
        file:close()
    end
    
    -- Call hooks
    for _, hook in ipairs(self.hooks) do
        pcall(hook, level, module, message)
    end
    
    -- Also print to console with colors
    if self.colors then
        local colored_entry = self:_colorize(log_entry, level)
        io.write(colored_entry)
    else
        io.write(log_entry)
    end
end

function RotatingLogger:rotate()
    -- Close current file
    local current_file = io.open(self.filename, "r")
    if not current_file then return end
    
    current_file:close()
    
    -- Rotate existing backups
    for i = self.max_files - 1, 1, -1 do
        local old_name = string.format("%s/%s.%d", self.backup_dir, self.filename, i)
        local new_name = string.format("%s/%s.%d", self.backup_dir, self.filename, i + 1)
        
        if os.rename(old_name, new_name) then
            self:debug("LOGGER", "Rotated %s to %s", old_name, new_name)
        end
    end
    
    -- Move current to backup.1
    local first_backup = string.format("%s/%s.1", self.backup_dir, self.filename)
    os.rename(self.filename, first_backup)
    
    -- Reset size counter
    self.current_size = 0
    
    self:info("LOGGER", "Log rotated, new file started")
end

function RotatingLogger:addHook(hook)
    table.insert(self.hooks, hook)
end

function RotatingLogger:addDiscordHook(channel_id, client, level_filter)
    self:addHook(function(level, module, message)
        if level >= (level_filter or Logging.LEVELS.ERROR) then
            local embed = client.Utils.createEmbed()
                :setTitle("Log Alert")
                :setDescription(string.format("**%s** - %s", module, message))
                :setColor(0xff0000)
                :setTimestamp(os.date("!%Y-%m-%dT%H:%M:%SZ"))
            
            pcall(function()
                client:sendMessage(channel_id, {embeds = {embed}})
            end)
        end
    end)
end

function RotatingLogger:getStats()
    local stats = {
        current_size = self.current_size,
        max_size = self.max_size,
        backup_files = 0,
        hooks_count = #self.hooks
    }
    
    -- Count backup files
    for i = 1, self.max_files do
        local backup_name = string.format("%s/%s.%d", self.backup_dir, self.filename, i)
        local file = io.open(backup_name, "r")
        if file then
            stats.backup_files = stats.backup_files + 1
            file:close()
        end
    end
    
    return stats
end

-- Delegate other logging methods
function RotatingLogger:debug(module, message, ...)
    self:log(Logging.LEVELS.DEBUG, module, message, ...)
end

function RotatingLogger:info(module, message, ...)
    self:log(Logging.LEVELS.INFO, module, message, ...)
end

function RotatingLogger:warn(module, message, ...)
    self:log(Logging.LEVELS.WARN, module, message, ...)
end

function RotatingLogger:error(module, message, ...)
    self:log(Logging.LEVELS.ERROR, module, message, ...)
end

function RotatingLogger:_levelToName(level)
    for name, lvl in pairs(Logging.LEVELS) do
        if lvl == level then
            return name
        end
    end
    return "UNKNOWN"
end

function RotatingLogger:_colorize(text, level)
    local colors = {
        [Logging.LEVELS.DEBUG] = "\27[36m", -- Cyan
        [Logging.LEVELS.INFO] = "\27[32m",  -- Green
        [Logging.LEVELS.WARN] = "\27[33m",  -- Yellow
        [Logging.LEVELS.ERROR] = "\27[31m", -- Red
    }
    local reset = "\27[0m"
    
    return (colors[level] or "") .. text .. reset
end

return RotatingLogger