local Logging = require("luacord.logging.logging")
local RotatingLogger = require("luacord.logging.rotating_logger")

return {
    Logging = Logging,
    RotatingLogger = RotatingLogger,
    create = function(...) return Logging:new(...) end,
    createRotating = function(...) return RotatingLogger:new(...) end,
    LEVELS = Logging.LEVELS
}