local Logging = {}
Logging.__index = Logging

-- Log levels
Logging.LEVELS = {
    DEBUG = 1,
    INFO = 2,
    WARN = 3,
    ERROR = 4,
    NONE = 5
}

function Logging:new(level, options)
    options = options or {}
    local self = setmetatable({}, Logging)
    self.level = level or Logging.LEVELS.INFO
    self.colors = options.colors ~= false
    self.timestamps = options.timestamps ~= false
    self.module_width = options.module_width or 15
    return self
end

function Logging:debug(module, message, ...)
    self:_log(Logging.LEVELS.DEBUG, module, message, ...)
end

function Logging:info(module, message, ...)
    self:_log(Logging.LEVELS.INFO, module, message, ...)
end

function Logging:warn(module, message, ...)
    self:_log(Logging.LEVELS.WARN, module, message, ...)
end

function Logging:error(module, message, ...)
    self:_log(Logging.LEVELS.ERROR, module, message, ...)
end

function Logging:_log(level, module, message, ...)
    if level < self.level then return end
    
    local level_name = self:_levelToName(level)
    local timestamp = self.timestamps and os.date("%H:%M:%S") or ""
    local module_str = module and string.format("[%-" .. self.module_width .. "s]", module) or ""
    
    -- Format message with optional arguments
    if select('#', ...) > 0 then
        message = string.format(message, ...)
    end
    
    local log_line = string.format("%s %s %s %s", 
        timestamp, level_name, module_str, message)
    
    if self.colors then
        log_line = self:_colorize(log_line, level)
    end
    
    print(log_line)
    
    -- Write to file if configured
    if self.log_file then
        self:_writeToFile(log_line)
    end
end

function Logging:_levelToName(level)
    for name, lvl in pairs(Logging.LEVELS) do
        if lvl == level then
            return name
        end
    end
    return "UNKNOWN"
end

function Logging:_colorize(text, level)
    local colors = {
        [Logging.LEVELS.DEBUG] = "\27[36m", -- Cyan
        [Logging.LEVELS.INFO] = "\27[32m",  -- Green
        [Logging.LEVELS.WARN] = "\27[33m",  -- Yellow
        [Logging.LEVELS.ERROR] = "\27[31m", -- Red
    }
    local reset = "\27[0m"
    
    return (colors[level] or "") .. text .. reset
end

function Logging:_writeToFile(text)
    if not self.log_file then return end
    
    local file = io.open(self.log_file, "a")
    if file then
        file:write(text .. "\n")
        file:close()
    end
end

function Logging:setLevel(level)
    if type(level) == "string" then
        level = Logging.LEVELS[level:upper()] or Logging.LEVELS.INFO
    end
    self.level = level
end

function Logging:setLogFile(filename)
    self.log_file = filename
end

-- Create default logger
local default_logger = Logging:new(Logging.LEVELS.INFO)

-- Module exports
return setmetatable(Logging, {
    __call = function(_, ...)
        return Logging:new(...)
    end,
    __index = function(_, key)
        if key == "DEBUG" then return Logging.LEVELS.DEBUG end
        if key == "INFO" then return Logging.LEVELS.INFO end
        if key == "WARN" then return Logging.LEVELS.WARN end
        if key == "ERROR" then return Logging.LEVELS.ERROR end
        if key == "NONE" then return Logging.LEVELS.NONE end
        return default_logger[key]
    end
})