local RateLimiter = require("luacord.ratelimiter.ratelimiter")
local BucketManager = require("luacord.ratelimiter.bucket_manager")

return {
    RateLimiter = RateLimiter,
    BucketManager = BucketManager,
    create = function(...) return RateLimiter:new(...) end,
    createBucketManager = function() return BucketManager:new() end
}