local RateLimiter = {}
RateLimiter.__index = RateLimiter

function RateLimiter:new(bucket_id, limit, reset_after)
    local self = setmetatable({}, RateLimiter)
    self.bucket_id = bucket_id
    self.limit = limit or 50
    self.remaining = limit or 50
    self.reset_after = reset_after or 1
    self.reset_time = os.time() + reset_after
    self.pending_requests = {}
    self.is_processing = false
    return self
end

-- Synchronous wait (blocks)
function RateLimiter:wait()
    local now = os.time()
    
    if now >= self.reset_time then
        self.remaining = self.limit
        self.reset_time = now + self.reset_after
    end
    
    if self.remaining <= 0 then
        local sleep_time = self.reset_time - now
        if sleep_time > 0 then
            self:_sleep(sleep_time)
        end
        self.remaining = self.limit
        self.reset_time = os.time() + self.reset_after
    end
    
    self.remaining = self.remaining - 1
end

-- Asynchronous wait (non-blocking, requires event loop)
function RateLimiter:wait_async(callback)
    local now = os.time()
    
    if now >= self.reset_time then
        self.remaining = self.limit
        self.reset_time = now + self.reset_after
    end
    
    if self.remaining > 0 then
        self.remaining = self.remaining - 1
        callback(true)
    else
        local sleep_time = self.reset_time - now
        table.insert(self.pending_requests, {
            callback = callback,
            execute_at = os.time() + sleep_time
        })
        self:_process_pending()
    end
end

function RateLimiter:_process_pending()
    if self.is_processing then return end
    self.is_processing = true
    
    local now = os.time()
    local has_pending = false
    
    for i = #self.pending_requests, 1, -1 do
        local request = self.pending_requests[i]
        
        if now >= request.execute_at then
            if self.remaining > 0 then
                self.remaining = self.remaining - 1
                request.callback(true)
                table.remove(self.pending_requests, i)
            else
                has_pending = true
            end
        else
            has_pending = true
        end
    end
    
    self.is_processing = false
    
    if has_pending then
        -- Schedule next processing
        self:_schedule_next_process()
    end
end

function RateLimiter:_schedule_next_process()
    -- This would integrate with an event loop in practice
    -- For now, we'll use a simple timer approach
    local min_time = math.huge
    for _, request in ipairs(self.pending_requests) do
        if request.execute_at < min_time then
            min_time = request.execute_at
        end
    end
    
    if min_time ~= math.huge then
        local delay = math.max(0.1, min_time - os.time())
        -- In a real async environment, you'd use event loop timers here
        -- For now, we'll just process on next call
    end
end

function RateLimiter:_sleep(seconds)
    if seconds > 0 then
        -- Use socket.sleep if available for non-blocking sleep in async contexts
        local ok, socket = pcall(require, "socket")
        if ok and socket.sleep then
            socket.sleep(seconds)
        else
            os.execute("sleep " .. seconds)
        end
    end
end

-- Update from Discord headers
function RateLimiter:updateFromHeaders(headers)
    if headers then
        if headers["x-ratelimit-remaining"] then
            self.remaining = tonumber(headers["x-ratelimit-remaining"]) or self.remaining
        end
        if headers["x-ratelimit-reset"] then
            self.reset_time = tonumber(headers["x-ratelimit-reset"]) or self.reset_time
        end
        if headers["x-ratelimit-limit"] then
            self.limit = tonumber(headers["x-ratelimit-limit"]) or self.limit
        end
    end
end

function RateLimiter:getRemaining()
    return self.remaining
end

function RateLimiter:getResetTime()
    return self.reset_time
end

function RateLimiter:getPendingCount()
    return #self.pending_requests
end

return RateLimiter