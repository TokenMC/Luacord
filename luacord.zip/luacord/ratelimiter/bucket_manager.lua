local BucketManager = {}
BucketManager.__index = BucketManager

function BucketManager:new()
    local self = setmetatable({}, BucketManager)
    self.buckets = {}
    self.global_limits = {}
    self.queue = {}
    self.processing = false
    return self
end

function BucketManager:getBucket(endpoint, method)
    -- Extract bucket ID from endpoint pattern
    local bucket_id = self:extractBucketId(endpoint, method)
    
    if not self.buckets[bucket_id] then
        -- Create new bucket with default limits
        self.buckets[bucket_id] = {
            limit = 50,
            remaining = 50,
            reset_time = os.time() + 1,
            reset_after = 1,
            endpoint = endpoint,
            method = method
        }
    end
    
    return self.buckets[bucket_id]
end

function BucketManager:extractBucketId(endpoint, method)
    -- Discord-specific bucket extraction logic
    local patterns = {
        {pattern = "/channels/(%d+)/messages", bucket = "channel_messages"},
        {pattern = "/channels/%d+", bucket = "channel_operations"},
        {pattern = "/guilds/(%d+)/members", bucket = "guild_members"},
        {pattern = "/guilds/%d+", bucket = "guild_operations"},
        {pattern = "/webhooks/%d+", bucket = "webhook_operations"},
    }
    
    for _, pattern in ipairs(patterns) do
        local match = endpoint:match(pattern.pattern)
        if match then
            return pattern.bucket .. ":" .. match
        end
    end
    
    -- Fallback to method + first path segment
    local first_segment = endpoint:match("/([^/]+)")
    return (method or "GET") .. ":" .. (first_segment or "global")
end

function BucketManager:updateFromHeaders(bucket, headers)
    if not headers then return end
    
    if headers["x-ratelimit-limit"] then
        bucket.limit = tonumber(headers["x-ratelimit-limit"]) or bucket.limit
    end
    
    if headers["x-ratelimit-remaining"] then
        bucket.remaining = tonumber(headers["x-ratelimit-remaining"]) or bucket.remaining
    end
    
    if headers["x-ratelimit-reset"] then
        bucket.reset_time = tonumber(headers["x-ratelimit-reset"]) or bucket.reset_time
    end
    
    if headers["x-ratelimit-reset-after"] then
        bucket.reset_after = tonumber(headers["x-ratelimit-reset-after"]) or bucket.reset_after
    end
    
    -- Update global rate limit info
    if headers["x-ratelimit-global"] then
        self.global_limits = {
            reset_time = bucket.reset_time,
            reset_after = bucket.reset_after
        }
    end
end

function BucketManager:waitForBucket(bucket_id, callback)
    local bucket = self.buckets[bucket_id]
    if not bucket then
        callback(true)
        return
    end
    
    local now = os.time()
    
    -- Check global rate limits first
    if self.global_limits.reset_time and now < self.global_limits.reset_time then
        local delay = self.global_limits.reset_time - now
        self:queueRequest(bucket_id, callback, delay)
        return
    end
    
    -- Check bucket-specific limits
    if now >= bucket.reset_time then
        bucket.remaining = bucket.limit
        bucket.reset_time = now + bucket.reset_after
    end
    
    if bucket.remaining > 0 then
        bucket.remaining = bucket.remaining - 1
        callback(true)
    else
        local delay = bucket.reset_time - now
        self:queueRequest(bucket_id, callback, delay)
    end
end

function BucketManager:queueRequest(bucket_id, callback, delay)
    if not self.queue[bucket_id] then
        self.queue[bucket_id] = {}
    end
    
    table.insert(self.queue[bucket_id], {
        callback = callback,
        execute_at = os.time() + delay
    })
    
    self:processQueue(bucket_id)
end

function BucketManager:processQueue(bucket_id)
    if self.processing then return end
    self.processing = true
    
    local queue = self.queue[bucket_id]
    if not queue then
        self.processing = false
        return
    end
    
    local now = os.time()
    local processed = 0
    
    for i = #queue, 1, -1 do
        local request = queue[i]
        
        if now >= request.execute_at then
            local bucket = self.buckets[bucket_id]
            if bucket and bucket.remaining > 0 then
                bucket.remaining = bucket.remaining - 1
                request.callback(true)
                table.remove(queue, i)
                processed = processed + 1
            end
        end
    end
    
    self.processing = false
    
    -- Schedule next processing if queue not empty
    if #queue > 0 then
        local next_time = math.huge
        for _, request in ipairs(queue) do
            if request.execute_at < next_time then
                next_time = request.execute_at
            end
        end
        
        local delay = math.max(0.1, next_time - now)
        -- In real implementation, use event loop timer
    end
    
    return processed
end

function BucketManager:getStats()
    local stats = {
        total_buckets = 0,
        active_buckets = 0,
        total_queued = 0,
        global_limited = self.global_limits.reset_time and true or false
    }
    
    for bucket_id, bucket in pairs(self.buckets) do
        stats.total_buckets = stats.total_buckets + 1
        if bucket.remaining < bucket.limit then
            stats.active_buckets = stats.active_buckets + 1
        end
    end
    
    for _, queue in pairs(self.queue) do
        stats.total_queued = stats.total_queued + #queue
    end
    
    return stats
end

return BucketManager