local EmbedTemplates = {}
EmbedTemplates.__index = EmbedTemplates

function EmbedTemplates:new()
    local self = setmetatable({}, EmbedTemplates)
    return self
end

function EmbedTemplates:success(title, description)
    return {
        title = title,
        description = description,
        color = 0x00ff00,
        timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        footer = {text = "Success"}
    }
end

function EmbedTemplates:error(title, description)
    return {
        title = title,
        description = description,
        color = 0xff0000,
        timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        footer = {text = "Error"}
    }
end

function EmbedTemplates:warning(title, description)
    return {
        title = title,
        description = description,
        color = 0xffff00,
        timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        footer = {text = "Warning"}
    }
end

function EmbedTemplates:info(title, description)
    return {
        title = title,
        description = description,
        color = 0x0099ff,
        timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        footer = {text = "Information"}
    }
end

function EmbedTemplates:usage(command, usage, examples)
    local embed = {
        title = "Command Usage: " .. command,
        color = 0x0099ff,
        fields = {
            {name = "Usage", value = "```" .. usage .. "```", inline = false}
        },
        timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        footer = {text = "Command Help"}
    }
    
    if examples then
        table.insert(embed.fields, {
            name = "Examples",
            value = "```" .. examples .. "```",
            inline = false
        })
    end
    
    return embed
end

function EmbedTemplates:paginated(title, items, page, page_size, color)
    page = page or 1
    page_size = page_size or 10
    color = color or 0x0099ff
    
    local start_index = (page - 1) * page_size + 1
    local end_index = math.min(start_index + page_size - 1, #items)
    local total_pages = math.ceil(#items / page_size)
    
    local description = ""
    for i = start_index, end_index do
        description = description .. string.format("%d. %s\n", i, items[i])
    end
    
    return {
        title = title,
        description = description,
        color = color,
        footer = {
            text = string.format("Page %d/%d • %d items", page, total_pages, #items)
        },
        timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
    }
end

return EmbedTemplates