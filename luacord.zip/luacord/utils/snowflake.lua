local Snowflake = {}
Snowflake.__index = Snowflake

function Snowflake:parse(snowflake)
    if not snowflake then return nil end
    
    local snowflake_num = tonumber(snowflake)
    if not snowflake_num then return nil end
    
    -- Discord epoch (2015-01-01 00:00:00 UTC)
    local discord_epoch = 1420070400000
    
    local timestamp = math.floor(snowflake_num / 4194304) + discord_epoch
    local worker_id = math.floor((snowflake_num % 4194304) / 1024)
    local process_id = math.floor((snowflake_num % 1024) / 16)
    local increment = snowflake_num % 16
    
    return {
        timestamp = timestamp,
        datetime = os.date("!%Y-%m-%d %H:%M:%S", timestamp / 1000),
        worker_id = worker_id,
        process_id = process_id,
        increment = increment,
        snowflake = snowflake
    }
end

function Snowflake:getTimestamp(snowflake)
    local parsed = self:parse(snowflake)
    return parsed and parsed.timestamp
end

function Snowflake:getAge(snowflake)
    local timestamp = self:getTimestamp(snowflake)
    if not timestamp then return nil end
    
    return os.time() * 1000 - timestamp
end

function Snowflake:isValid(snowflake)
    local parsed = self:parse(snowflake)
    if not parsed then return false end
    
    -- Basic validation: timestamp should be after Discord epoch and not in future
    local now = os.time() * 1000
    return parsed.timestamp > 1420070400000 and parsed.timestamp <= now + 60000 -- Allow 1min future for clock skew
end

function Snowflake:generate()
    -- Note: This is for testing only, real snowflakes come from Discord
    local timestamp = (os.time() * 1000) - 1420070400000
    return tostring((timestamp << 22) + math.random(0, 4095))
end

return Snowflake