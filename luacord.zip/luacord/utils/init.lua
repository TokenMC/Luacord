local Utils = require("luacord.utils.utils")
local Snowflake = require("luacord.utils.snowflake")
local EmbedTemplates = require("luacord.utils.embed_templates")
local Markdown = require("luacord.utils.markdown")

return {
    Utils = Utils,
    Snowflake = Snowflake,
    EmbedTemplates = EmbedTemplates,
    Markdown = Markdown,
    -- Convenience exports
    createEmbed = Utils.createEmbed,
    createButton = Utils.createButton,
    createActionRow = Utils.createActionRow,
    createSelectMenu = Utils.createSelectMenu,
    calculatePermissions = Utils.calculatePermissions,
    parseSnowflake = Snowflake.parse,
    successEmbed = function(...) return EmbedTemplates:success(...) end,
    errorEmbed = function(...) return EmbedTemplates:error(...) end,
    bold = Markdown.bold,
    italic = Markdown.italic
}