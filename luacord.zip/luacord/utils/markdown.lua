local Markdown = {}
Markdown.__index = Markdown

function Markdown:new()
    local self = setmetatable({}, Markdown)
    return self
end

-- Text formatting
function Markdown.bold(text)
    return "**" .. text .. "**"
end

function Markdown.italic(text)
    return "*" .. text .. "*"
end

function Markdown.boldItalic(text)
    return "***" .. text .. "***"
end

function Markdown.underline(text)
    return "__" .. text .. "__"
end

function Markdown.strikethrough(text)
    return "~~" .. text .. "~~"
end

function Markdown.code(text)
    return "`" .. text .. "`"
end

function Markdown.codeBlock(text, language)
    language = language or ""
    return "```" .. language .. "\n" .. text .. "\n```"
end

function Markdown.quote(text)
    return "> " .. text:gsub("\n", "\n> ")
end

function Markdown.blockQuote(text)
    return ">>> " .. text
end

function Markdown.spoiler(text)
    return "||" .. text .. "||"
end

-- Mentions
function Markdown.userMention(user_id)
    return "<@" .. user_id .. ">"
end

function Markdown.channelMention(channel_id)
    return "<#" .. channel_id .. ">"
end

function Markdown.roleMention(role_id)
    return "<@&" .. role_id .. ">"
end

function Markdown.emoji(emoji_name, emoji_id)
    if emoji_id then
        return "<:" .. emoji_name .. ":" .. emoji_id .. ">"
    else
        return ":" .. emoji_name .. ":"
    end
end

function Markdown.animatedEmoji(emoji_name, emoji_id)
    return "<a:" .. emoji_name .. ":" .. emoji_id .. ">"
end

function Markdown.timestamp(timestamp, style)
    style = style or "f" -- Default style
    local valid_styles = {["t"] = true, ["T"] = true, ["d"] = true, ["D"] = true, ["f"] = true, ["F"] = true, ["R"] = true}
    
    if not valid_styles[style] then
        style = "f"
    end
    
    if type(timestamp) == "number" then
        timestamp = math.floor(timestamp)
    elseif type(timestamp) == "string" then
        timestamp = math.floor(tonumber(timestamp) or os.time())
    else
        timestamp = os.time()
    end
    
    return "<t:" .. timestamp .. ":" .. style .. ">"
end

-- URL formatting
function Markdown.link(text, url)
    return "[" .. text .. "](" .. url .. ")"
end

-- Custom emoji helpers
function Markdown.checkmark()
    return "✅"
end

function Markdown.crossmark()
    return "❌"
end

function Markdown.warning()
    return "⚠️"
end

function Markdown.info()
    return "ℹ️"
end

function Markdown.loading()
    return "⌛"
end

function Markdown.success()
    return "🎉"
end

function Markdown.error()
    return "🚫"
end

-- Progress bar
function Markdown.progressBar(percentage, length)
    length = length or 10
    percentage = math.max(0, math.min(100, percentage or 0))
    
    local filled = math.floor((percentage / 100) * length)
    local empty = length - filled
    
    local bar = ""
    if filled > 0 then
        bar = bar .. string.rep("█", filled)
    end
    if empty > 0 then
        bar = bar .. string.rep("░", empty)
    end
    
    return "`[" .. bar .. "]` " .. math.floor(percentage) .. "%"
end

-- List formatting
function Markdown.orderedList(items)
    local result = ""
    for i, item in ipairs(items) do
        result = result .. i .. ". " .. item .. "\n"
    end
    return result
end

function Markdown.unorderedList(items)
    local result = ""
    for _, item in ipairs(items) do
        result = result .. "• " .. item .. "\n"
    end
    return result
end

-- Table formatting (basic)
function Markdown.table(headers, rows)
    if #headers == 0 then return "" end
    
    local lines = {}
    
    -- Header row
    local header_line = "| " .. table.concat(headers, " | ") .. " |"
    table.insert(lines, header_line)
    
    -- Separator
    local separator = {}
    for _ in ipairs(headers) do
        table.insert(separator, "---")
    end
    table.insert(lines, "| " .. table.concat(separator, " | ") .. " |")
    
    -- Data rows
    for _, row in ipairs(rows) do
        if #row == #headers then
            table.insert(lines, "| " .. table.concat(row, " | ") .. " |")
        end
    end
    
    return table.concat(lines, "\n")
end

-- Escape markdown characters
function Markdown.escape(text)
    return text:gsub("([%*%_%`%|%~%>%!])", "\\%1")
end

-- Remove markdown
function Markdown.strip(text)
    -- Remove bold, italic, underline, strikethrough
    text = text:gsub("%*%*([%*%s%S]-)%*%*", "%1")
    text = text:gsub("%*([%*%s%S]-)%*", "%1")
    text = text:gsub("__([%_%s%S]-)__", "%1")
    text = text:gsub("~~([%~%s%S]-)~~", "%1")
    
    -- Remove code blocks and inline code
    text = text:gsub("```[%w]*\n([%s%S]-)\n```", "%1")
    text = text:gsub("`([%`%s%S]-)`", "%1")
    
    -- Remove spoilers
    text = text:gsub("||([%|%s%S]-)||", "%1")
    
    -- Remove quotes
    text = text:gsub("^>%s?", "")
    text = text:gsub("\n>%s?", "\n")
    
    return text
end

return Markdown