local https = require("ssl.https")
local ltn12 = require("ltn12")
local json = require("dkjson")

local Utils = {}

-- HTTP request with better error handling
function Utils.httpRequest(method, url, token, data)
    local body = data and json.encode(data) or nil
    local response_body = {}
    local headers = {}

    local request = {
        url = url,
        method = method,
        headers = {
            ["Authorization"] = token,
            ["Content-Type"] = "application/json",
            ["User-Agent"] = "Luacord (https://github.com/luacord, 1.0.0)"
        },
        sink = ltn12.sink.table(response_body)
    }

    if body then
        request.headers["Content-Length"] = #body
        request.source = ltn12.source.string(body)
    end

    local success, code, response_headers = https.request(request)
    local response = table.concat(response_body)

    -- Store headers for rate limit info
    if response_headers then
        headers = response_headers
    end

    if code == 200 or code == 201 or code == 204 then
        if response ~= "" then
            return json.decode(response), headers
        end
        return true, headers
    else
        local error_msg = "HTTP Error " .. code .. " on " .. method .. " " .. url
        if response ~= "" then
            local error_data = json.decode(response)
            error_msg = error_msg .. ": " .. (error_data.message or "Unknown error")
        end
        print("❌ " .. error_msg)
        return nil, headers, code
    end
end

-- URL encoding for emojis
function Utils.urlEncode(str)
    if str then
        return (str:gsub("[^%w%-%.%_%~]", function(c)
            return string.format("%%%02X", string.byte(c))
        end))
    end
    return ""
end

-- List files in directory
function Utils.listFiles(directory)
    local files = {}
    local sep = package.config:sub(1,1)
    
    local cmd = sep == "\\" and 'dir "' .. directory .. '" /b' or 'ls "' .. directory .. '"'
    local p = io.popen(cmd)
    
    if p then
        for file in p:lines() do
            table.insert(files, file)
        end
        p:close()
    end
    
    return files
end

-- Snowflake to timestamp
function Utils.snowflakeToTimestamp(snowflake)
    if not snowflake then return nil end
    return tonumber(snowflake) / 4194304 + 1420070400000
end

-- Embed builder
function Utils.createEmbed()
    return {
        title = nil,
        type = "rich",
        description = nil,
        url = nil,
        timestamp = nil,
        color = nil,
        footer = nil,
        image = nil,
        thumbnail = nil,
        author = nil,
        fields = {}
    }
end

-- Component builders
function Utils.createActionRow()
    return {
        type = 1,
        components = {}
    }
end

function Utils.createButton(style, label, custom_id, options)
    options = options or {}
    return {
        type = 2,
        style = style,
        label = label,
        custom_id = custom_id,
        url = options.url,
        disabled = options.disabled or false,
        emoji = options.emoji
    }
end

function Utils.createSelectMenu(custom_id, options, placeholder, min_values, max_values)
    return {
        type = 3,
        custom_id = custom_id,
        options = options,
        placeholder = placeholder,
        min_values = min_values or 1,
        max_values = max_values or 1,
        disabled = false
    }
end

-- Permission calculator
function Utils.calculatePermissions(...)
    local permissions = 0
    local perm_list = {...}
    
    local perm_values = {
        create_instant_invite = 0x00000000001,
        kick_members = 0x00000000002,
        ban_members = 0x00000000004,
        administrator = 0x00000000008,
        manage_channels = 0x00000000010,
        manage_guild = 0x00000000020,
        add_reactions = 0x00000000040,
        view_audit_log = 0x00000000080,
        priority_speaker = 0x00000000100,
        stream = 0x00000000200,
        view_channel = 0x00000000400,
        send_messages = 0x00000000800,
        send_tts_messages = 0x00000001000,
        manage_messages = 0x00000002000,
        embed_links = 0x00000004000,
        attach_files = 0x00000008000,
        read_message_history = 0x00000010000,
        mention_everyone = 0x00000020000,
        use_external_emojis = 0x00000040000,
        view_guild_insights = 0x00000080000,
        connect = 0x00000100000,
        speak = 0x00000200000,
        mute_members = 0x00000400000,
        deafen_members = 0x00000800000,
        move_members = 0x00001000000,
        use_vad = 0x00002000000,
        change_nickname = 0x00004000000,
        manage_nicknames = 0x00008000000,
        manage_roles = 0x00010000000,
        manage_webhooks = 0x00020000000,
        manage_emojis_and_stickers = 0x00040000000,
        use_application_commands = 0x00080000000,
        request_to_speak = 0x00100000000,
        manage_events = 0x00200000000,
        manage_threads = 0x00400000000,
        create_public_threads = 0x00800000000,
        create_private_threads = 0x01000000000,
        use_external_stickers = 0x02000000000,
        send_messages_in_threads = 0x04000000000,
        use_embedded_activities = 0x08000000000,
        moderate_members = 0x10000000000
    }
    
    for _, perm in ipairs(perm_list) do
        if perm_values[perm] then
            permissions = permissions | perm_values[perm]
        end
    end
    
    return tostring(permissions)
end

-- Color utilities
function Utils.rgbToInt(r, g, b)
    return r * 65536 + g * 256 + b
end

function Utils.hexToInt(hex)
    hex = hex:gsub("#", "")
    return tonumber(hex, 16)
end

-- Table utilities
function Utils.mergeTables(t1, t2)
    local result = {}
    for k, v in pairs(t1) do result[k] = v end
    for k, v in pairs(t2) do result[k] = v end
    return result
end

function Utils.deepCopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[Utils.deepCopy(orig_key)] = Utils.deepCopy(orig_value)
        end
        setmetatable(copy, Utils.deepCopy(getmetatable(orig)))
    else
        copy = orig
    end
    return copy
end

return Utils