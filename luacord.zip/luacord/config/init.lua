local ConfigLoader = require("luacord.config.loader")

return {
    ConfigLoader = ConfigLoader,
    load = function(...) return ConfigLoader:load(...) end,
    generateTemplate = function() return ConfigLoader:generateTemplate() end
}