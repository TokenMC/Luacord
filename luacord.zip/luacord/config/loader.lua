local ConfigLoader = {}
ConfigLoader.__index = ConfigLoader

function ConfigLoader:new()
    local self = setmetatable({}, ConfigLoader)
    return self
end

function ConfigLoader:load(filepath)
    local ext = filepath:match("%.([^%.]+)$")
    
    if ext == "json" then
        return self:loadJSON(filepath)
    elseif ext == "yaml" or ext == "yml" then
        return self:loadYAML(filepath)
    elseif ext == "lua" then
        return self:loadLua(filepath)
    else
        error("Unsupported config format: " .. (ext or "unknown"))
    end
end

function ConfigLoader:loadJSON(filepath)
    local file = io.open(filepath, "r")
    if not file then
        error("Config file not found: " .. filepath)
    end
    
    local content = file:read("*a")
    file:close()
    
    local json = require("dkjson")
    local config, pos, err = json.decode(content, 1, nil)
    
    if err then
        error("Invalid JSON config: " .. err)
    end
    
    return self:validateConfig(config)
end

function ConfigLoader:loadYAML(filepath)
    -- Would require a YAML library
    -- For now, return empty table
    return self:validateConfig({})
end

function ConfigLoader:loadLua(filepath)
    local chunk, err = loadfile(filepath)
    if not chunk then
        error("Failed to load Lua config: " .. err)
    end
    
    local config = chunk()
    return self:validateConfig(config or {})
end

function ConfigLoader:validateConfig(config)
    config = config or {}
    
    -- Set defaults
    config.token = config.token or os.getenv("DISCORD_TOKEN")
    config.intents = config.intents or {"guilds", "guild_messages"}
    config.presence = config.presence or {
        status = "online",
        activities = {{
            name = "Luacord",
            type = 0
        }}
    }
    
    config.logging = config.logging or {
        level = "INFO",
        file = "luacord.log",
        max_size = 10485760,
        max_files = 5
    }
    
    config.cache = config.cache or {
        ttl = 300,
        max_size = 1000
    }
    
    config.rate_limiting = config.rate_limiting or {
        enabled = true,
        max_queue_size = 100
    }
    
    config.plugins = config.plugins or {}
    config.cogs = config.cogs or {}
    
    -- Validate required fields
    if not config.token then
        error("Discord token is required in configuration")
    end
    
    return config
end

function ConfigLoader:generateTemplate()
    return {
        token = "YOUR_BOT_TOKEN_HERE",
        intents = {"guilds", "guild_messages", "message_content"},
        sharding = {
            total_shards = 1,
            shard_ids = {0}
        },
        presence = {
            status = "online",
            activities = {{
                name = "Luacord",
                type = 0
            }}
        },
        logging = {
            level = "INFO",
            file = "luacord.log",
            max_size = 10485760,
            max_files = 5,
            colors = true
        },
        cache = {
            ttl = 300,
            max_size = 1000
        },
        rate_limiting = {
            enabled = true,
            max_queue_size = 100
        },
        plugins = {
            "metrics",
            "web_dashboard"
        },
        cogs = {
            "moderation",
            "music",
            "utility"
        }
    }
end

return ConfigLoader