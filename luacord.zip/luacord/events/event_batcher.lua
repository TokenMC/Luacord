local EventBatcher = {}
EventBatcher.__index = EventBatcher

function EventBatcher:new(batch_size, flush_interval)
    local self = setmetatable({}, EventBatcher)
    self.batch_size = batch_size or 50
    self.flush_interval = flush_interval or 2 -- seconds
    self.batches = {}
    self.timers = {}
    self.handlers = {}
    return self
end

-- Register batched event handler
function EventBatcher:on(event, handler, options)
    options = options or {}
    self.handlers[event] = {
        handler = handler,
        key_func = options.key_func, -- Function to group events (e.g., by guild_id)
        max_batch_size = options.max_batch_size or self.batch_size,
        flush_interval = options.flush_interval or self.flush_interval
    }
end

-- Add event to batch
function EventBatcher:add(event, data)
    local handler = self.handlers[event]
    if not handler then return false end
    
    local batch_key = handler.key_func and handler.key_func(data) or "default"
    local full_key = event .. ":" .. batch_key
    
    if not self.batches[full_key] then
        self.batches[full_key] = {
            events = {},
            count = 0,
            created_at = os.time()
        }
        
        -- Set flush timer
        self.timers[full_key] = os.time() + handler.flush_interval
    end
    
    local batch = self.batches[full_key]
    table.insert(batch.events, data)
    batch.count = batch.count + 1
    
    -- Flush if batch size reached
    if batch.count >= handler.max_batch_size then
        self:flush(full_key)
    end
    
    return true
end

-- Flush specific batch
function EventBatcher:flush(full_key)
    local batch = self.batches[full_key]
    if not batch or batch.count == 0 then return end
    
    local event = full_key:match("([^:]+):")
    local handler = self.handlers[event]
    
    if handler and handler.handler then
        pcall(handler.handler, batch.events)
    end
    
    self.batches[full_key] = nil
    self.timers[full_key] = nil
end

-- Flush all batches
function EventBatcher:flushAll()
    for full_key in pairs(self.batches) do
        self:flush(full_key)
    end
end

-- Process timed-out batches
function EventBatcher:processTimedOut()
    local now = os.time()
    for full_key, flush_time in pairs(self.timers) do
        if now >= flush_time then
            self:flush(full_key)
        end
    end
end

-- Start automatic processing
function EventBatcher:startAutoProcess(interval)
    interval = interval or 1 -- second
    self.auto_process = true
    
    while self.auto_process do
        self:processTimedOut()
        os.execute("sleep " .. interval)
    end
end

function EventBatcher:stopAutoProcess()
    self.auto_process = false
    self:flushAll()
end

function EventBatcher:getStats()
    local total_batches = 0
    local total_events = 0
    
    for _, batch in pairs(self.batches) do
        total_batches = total_batches + 1
        total_events = total_events + batch.count
    end
    
    return {
        total_batches = total_batches,
        total_events = total_events,
        handlers_count = self:getHandlerCount()
    }
end

function EventBatcher:getHandlerCount()
    local count = 0
    for _ in pairs(self.handlers) do
        count = count + 1
    end
    return count
end

return EventBatcher