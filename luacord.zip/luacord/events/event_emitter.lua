local EventEmitter = {}
EventEmitter.__index = EventEmitter

function EventEmitter:new()
    local self = setmetatable({}, EventEmitter)
    self._callbacks = {}
    self._wildcard_callbacks = {}
    self._event_stats = {}
    self._filters = {}
    return self
end

function EventEmitter:on(event, callback, options)
    options = options or {}
    
    if event == "*" then
        table.insert(self._wildcard_callbacks, {
            callback = callback,
            filter = options.filter
        })
    else
        if not self._callbacks[event] then
            self._callbacks[event] = {}
        end
        
        table.insert(self._callbacks[event], {
            callback = callback,
            filter = options.filter,
            once = options.once
        })
    end
    
    -- Initialize stats
    if not self._event_stats[event] then
        self._event_stats[event] = {
            count = 0,
            total_handlers = 0,
            last_triggered = nil
        }
    end
    self._event_stats[event].total_handlers = #self._callbacks[event] or 0
end

function EventEmitter:once(event, callback, options)
    options = options or {}
    options.once = true
    self:on(event, callback, options)
end

function EventEmitter:off(event, callback)
    if not self._callbacks[event] then return end
    
    for i, handler in ipairs(self._callbacks[event]) do
        if handler.callback == callback then
            table.remove(self._callbacks[event], i)
            break
        end
    end
end

function EventEmitter:emit(event, data)
    -- Update statistics
    if not self._event_stats[event] then
        self._event_stats[event] = {
            count = 0,
            total_handlers = 0,
            last_triggered = os.time()
        }
    end
    self._event_stats[event].count = self._event_stats[event].count + 1
    self._event_stats[event].last_triggered = os.time()
    
    local handlers_called = 0
    
    -- Wildcard handlers
    for _, handler in ipairs(self._wildcard_callbacks) do
        if self:_passesFilter(handler.filter, event, data) then
            pcall(handler.callback, event, data)
            handlers_called = handlers_called + 1
        end
    end
    
    -- Specific event handlers
    if self._callbacks[event] then
        local to_remove = {}
        
        for i, handler in ipairs(self._callbacks[event]) do
            if self:_passesFilter(handler.filter, event, data) then
                pcall(handler.callback, data)
                handlers_called = handlers_called + 1
                
                if handler.once then
                    table.insert(to_remove, i)
                end
            end
        end
        
        -- Remove once handlers
        for i = #to_remove, 1, -1 do
            table.remove(self._callbacks[event], to_remove[i])
        end
    end
    
    -- Pattern matching for event groups (e.g., "guild_*")
    for pattern, handlers in pairs(self._callbacks) do
        if pattern ~= event and self:_matchesPattern(pattern, event) then
            for _, handler in ipairs(handlers) do
                if self:_passesFilter(handler.filter, event, data) then
                    pcall(handler.callback, data)
                    handlers_called = handlers_called + 1
                end
            end
        end
    end
    
    return handlers_called
end

function EventEmitter:_matchesPattern(pattern, event)
    if pattern:sub(-2) == "_*" then
        local prefix = pattern:sub(1, -3)
        return event:sub(1, #prefix) == prefix
    end
    return false
end

function EventEmitter:_passesFilter(filter, event, data)
    if not filter then return true end
    
    if type(filter) == "function" then
        return pcall(filter, event, data)
    elseif type(filter) == "table" then
        for key, value in pairs(filter) do
            if data[key] ~= value then
                return false
            end
        end
        return true
    end
    
    return true
end

function EventEmitter:getEventStats(event)
    if event then
        return self._event_stats[event] or {count = 0, total_handlers = 0, last_triggered = nil}
    else
        return self._event_stats
    end
end

function EventEmitter:getTopEvents(limit)
    limit = limit or 10
    local events = {}
    
    for event, stats in pairs(self._event_stats) do
        table.insert(events, {
            event = event,
            count = stats.count,
            last_triggered = stats.last_triggered
        })
    end
    
    table.sort(events, function(a, b)
        return a.count > b.count
    end)
    
    return {table.unpack(events, 1, limit)}
end

return EventEmitter