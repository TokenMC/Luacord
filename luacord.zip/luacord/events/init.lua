local EventEmitter = require("luacord.events.event_emitter")
local EventBatcher = require("luacord.events.event_batcher")

return {
    EventEmitter = EventEmitter,
    EventBatcher = EventBatcher,
    createEmitter = function() return EventEmitter:new() end,
    createBatcher = function(...) return EventBatcher:new(...) end
}