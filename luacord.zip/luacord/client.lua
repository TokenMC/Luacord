local ws = require("websocket.client").sync
local json = require("dkjson")

-- Import modular components
local RateLimiter = require("luacord.ratelimiter")
local Cache = require("luacord.cache")
local Utils = require("luacord.utils")
local ObjectManager = require("luacord.object_manager")
local CommandSystem = require("luacord.command_system")
local Logging = require("luacord.logging")
local EventBatcher = require("luacord.event_batcher")
local AsyncHandler = require("luacord.async_handler")

local Client = {}
Client.__index = Client

function Client:new(token, options)
    options = options or {}
    local self = setmetatable({}, Client)
    
    -- Core properties
    self.token = "Bot " .. token
    self.gateway = "wss://gateway.discord.gg/?v=10&encoding=json"
    self._callbacks = {}
    
    -- Modular systems
    self.cache = Cache:new(options.cache_ttl)
    self.objects = ObjectManager:new(self.cache)
    self.rate_limiters = {}
    self.commands = CommandSystem:new(self)
    self.logger = options.logger or Logging:new(Logging.LEVELS.INFO)
    self.event_batcher = EventBatcher:new()
    self.async_handler = AsyncHandler:new()
    
    -- Connection state
    self.sequence = nil
    self.session_id = nil
    self.resume_gateway_url = nil
    self.heartbeat_ack = true
    self.heartbeat_interval = nil
    self.user = nil
    
    -- Configuration
    self.auto_reconnect = options.auto_reconnect ~= false
    self.max_reconnect_attempts = options.max_reconnect_attempts or 5
    self.reconnect_delay = options.reconnect_delay or 5
    self.intents = options.intents or Client.calculateIntents("guilds", "guild_messages")
    self.presence = options.presence
    
    -- Auto-sync commands
    self.auto_sync_commands = options.auto_sync_commands or false
    self.command_sync_guild = options.command_sync_guild
    
    self.logger:info("CLIENT", "Luacord Client initialized")
    return self
end

-- Delegate object management to ObjectManager
function Client:setUser(user) return self.objects:setUser(user) end
function Client:getUser(user_id) return self.objects:getUser(user_id) end
function Client:setGuild(guild) return self.objects:setGuild(guild) end
function Client:getGuild(guild_id) return self.objects:getGuild(guild_id) end
function Client:setChannel(channel) return self.objects:setChannel(channel) end
function Client:getChannel(channel_id) return self.objects:getChannel(channel_id) end

-- Delegate command management to CommandSystem
function Client:registerCommand(...) return self.commands:registerCommand(...) end
function Client:registerCog(...) return self.commands:registerCog(...) end
function Client:syncCommands(...) return self.commands:syncCommands(...) end

-- Enhanced event system with batching
function Client:on(event, callback, options)
    options = options or {}
    
    if options.batched then
        -- Use event batcher for high-volume events
        self.event_batcher:on(event, callback, options)
    else
        -- Standard event handling
        if not self._callbacks[event] then
            self._callbacks[event] = {}
        end
        table.insert(self._callbacks[event], callback)
    end
end

-- Rest of the client implementation remains similar but uses the new modular systems
-- ... (connect, run, HTTP methods, etc.)

return Client