-- This file exports example cogs for users to learn from
return {
    -- These are just references, actual cogs are separate files
    available = {"moderation", "music", "utility", "admin"}
}