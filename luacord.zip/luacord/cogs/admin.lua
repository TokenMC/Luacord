local Admin = {}
Admin.__index = Admin

Admin.version = "1.0.0"
Admin.description = "Bot administration commands"

function Admin:setup(client)
    self.client = client
    
    self.commands = {
        reload = {
            description = "Reload a cog",
            options = {
                {
                    name = "cog",
                    description = "Cog name to reload",
                    type = 3, -- STRING
                    required = true
                }
            },
            callback = function(client, interaction)
                local cog_name = interaction.data.options[1].value
                
                if client.cog_manager:reloadCog(cog_name) then
                    client:replyToInteraction(interaction.id, interaction.token, {
                        type = 4,
                        data = {content: "✅ Cog `" .. cog_name .. "` reloaded successfully"}
                    })
                else
                    client:replyToInteraction(interaction.id, interaction.token, {
                        type = 4,
                        data = {content: "❌ Failed to reload cog `" .. cog_name .. "`"}
                    })
                end
            end
        },
        
        stats = {
            description = "Show bot statistics",
            callback = function(client, interaction)
                local cache_stats = client.cache:getStats()
                local command_stats = client.commands:getStats()
                local event_stats = client.event_emitter:getEventStats()
                
                local embed = client.Utils.createEmbed()
                    :setTitle("📈 Bot Statistics")
                    :setColor(0x00ff00)
                    :addField("Cache Size", tostring(cache_stats.size), true)
                    :addField("Cache Hit Rate", string.format("%.1f%%", cache_stats.hit_rate), true)
                    :addField("Commands Registered", tostring(command_stats.total_commands), true)
                    :addField("Cogs Loaded", tostring(command_stats.cogs), true)
                    :addField("Events Processed", tostring(event_stats.total or 0), true)
                    :setTimestamp(os.date("!%Y-%m-%dT%H:%M:%SZ"))
                
                client:replyToInteraction(interaction.id, interaction.token, {
                    type = 4,
                    data = {embeds = {embed}}
                })
            end
        }
    }
    
    for name, command in pairs(self.commands) do
        client:registerCommand(name, command.description, command.options, command.callback, "admin")
    end
    
    client.logger:info("ADMIN", "Admin cog loaded")
end

return Admin