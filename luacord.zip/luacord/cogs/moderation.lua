local Moderation = {}
Moderation.__index = Moderation

Moderation.version = "1.0.0"
Moderation.description = "Moderation commands for server management"

function Moderation:setup(client)
    self.client = client
    
    -- Register moderation commands
    self.commands = {
        ban = {
            description = "Ban a user from the server",
            options = {
                {
                    name = "user",
                    description = "The user to ban",
                    type = 6, -- USER
                    required = true
                },
                {
                    name = "reason",
                    description = "Reason for the ban",
                    type = 3, -- STRING
                    required = false
                }
            },
            callback = function(client, interaction)
                local user = interaction.data.options[1].value
                local reason = interaction.data.options[2] and interaction.data.options[2].value or "No reason provided"
                
                -- In real implementation, you'd call the ban API
                local embed = client.Utils.createEmbed()
                    :setTitle("🔨 User Banned")
                    :setColor(0xff0000)
                    :addField("User", "<@" .. user .. ">", true)
                    :addField("Reason", reason, true)
                    :addField("Moderator", "<@" .. interaction.member.user.id .. ">", true)
                    :setTimestamp(os.date("!%Y-%m-%dT%H:%M:%SZ"))
                
                client:replyToInteraction(interaction.id, interaction.token, {
                    type = 4,
                    data = {embeds = {embed}}
                })
            end
        },
        
        kick = {
            description = "Kick a user from the server",
            options = {
                {
                    name = "user",
                    description = "The user to kick",
                    type = 6, -- USER
                    required = true
                },
                {
                    name = "reason",
                    description = "Reason for the kick",
                    type = 3, -- STRING
                    required = false
                }
            },
            callback = function(client, interaction)
                local user = interaction.data.options[1].value
                local reason = interaction.data.options[2] and interaction.data.options[2].value or "No reason provided"
                
                local embed = client.Utils.createEmbed()
                    :setTitle("👢 User Kicked")
                    :setColor(0xffaa00)
                    :addField("User", "<@" .. user .. ">", true)
                    :addField("Reason", reason, true)
                    :addField("Moderator", "<@" .. interaction.member.user.id .. ">", true)
                    :setTimestamp(os.date("!%Y-%m-%dT%H:%M:%SZ"))
                
                client:replyToInteraction(interaction.id, interaction.token, {
                    type = 4,
                    data = {embeds = {embed}}
                })
            end
        }
    }
    
    -- Register all commands
    for name, command in pairs(self.commands) do
        client:registerCommand(name, command.description, command.options, command.callback, "moderation")
    end
    
    client.logger:info("MODERATION", "Moderation cog loaded with %d commands", #self.commands)
end

function Moderation:cleanup(client)
    client.logger:info("MODERATION", "Moderation cog unloaded")
end

return Moderation