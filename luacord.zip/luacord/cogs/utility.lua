local Utility = {}
Utility.__index = Utility

Utility.version = "1.0.0"
Utility.description = "Utility commands"

function Utility:setup(client)
    self.client = client
    
    self.commands = {
        ping = {
            description = "Check bot latency",
            callback = function(client, interaction)
                local start_time = os.clock()
                
                client:replyToInteraction(interaction.id, interaction.token, {
                    type = 4,
                    data = {content: "🏓 Pong! Calculating..."}
                }, function()
                    local latency = (os.clock() - start_time) * 1000
                    
                    client:editInteractionResponse(client.user.id, interaction.token, {
                        content = string.format("🏓 Pong! Latency: %.0fms", latency)
                    })
                end)
            end
        },
        
        userinfo = {
            description = "Get information about a user",
            options = {
                {
                    name = "user",
                    description = "The user to get info about",
                    type = 6, -- USER
                    required = false
                }
            },
            callback = function(client, interaction)
                local user_id = interaction.data.options and interaction.data.options[1] and interaction.data.options[1].value or interaction.member.user.id
                local user = interaction.data.resolved and interaction.data.resolved.users[user_id]
                
                if user then
                    local embed = client.Utils.createEmbed()
                        :setTitle("👤 User Information")
                        :setThumbnail(user.avatar and string.format("https://cdn.discordapp.com/avatars/%s/%s.png", user.id, user.avatar) or nil)
                        :addField("Username", user.username, true)
                        :addField("ID", user.id, true)
                        :addField("Account Created", client.Utils.Markdown.timestamp(client.Utils.Snowflake.getTimestamp(user.id)), true)
                        :setColor(0x0099ff)
                        :setTimestamp(os.date("!%Y-%m-%dT%H:%M:%SZ"))
                    
                    client:replyToInteraction(interaction.id, interaction.token, {
                        type = 4,
                        data = {embeds = {embed}}
                    })
                end
            end
        }
    }
    
    for name, command in pairs(self.commands) do
        client:registerCommand(name, command.description, command.options, command.callback, "utility")
    end
    
    client.logger:info("UTILITY", "Utility cog loaded")
end

return Utility