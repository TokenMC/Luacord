local ObjectManager = {}
ObjectManager.__index = ObjectManager

function ObjectManager:new(cache)
    local self = setmetatable({}, ObjectManager)
    self.cache = cache
    return self
end

-- User management
function ObjectManager:setUser(user)
    if user and user.id then
        self.cache:set("user_" .. user.id, user, 3600) -- 1 hour TTL
        if user.username then
            self.cache:set("username_" .. user.username:lower(), user.id, 3600)
        end
    end
end

function ObjectManager:getUser(user_id)
    return self.cache:get("user_" .. user_id)
end

function ObjectManager:getUserByUsername(username)
    local user_id = self.cache:get("username_" .. username:lower())
    return user_id and self:getUser(user_id)
end

-- Guild management
function ObjectManager:setGuild(guild)
    if guild and guild.id then
        self.cache:set("guild_" .. guild.id, guild, 1800) -- 30 minutes
        if guild.name then
            self.cache:set("guildname_" .. guild.name:lower(), guild.id, 1800)
        end
    end
end

function ObjectManager:getGuild(guild_id)
    return self.cache:get("guild_" .. guild_id)
end

function ObjectManager:getGuildByName(name)
    local guild_id = self.cache:get("guildname_" .. name:lower())
    return guild_id and self:getGuild(guild_id)
end

-- Channel management
function ObjectManager:setChannel(channel)
    if channel and channel.id then
        self.cache:set("channel_" .. channel.id, channel, 1800)
        if channel.guild_id then
            -- Store channel list per guild
            local guild_channels = self.cache:get("guild_channels_" .. channel.guild_id) or {}
            guild_channels[channel.id] = true
            self.cache:set("guild_channels_" .. channel.guild_id, guild_channels, 1800)
        end
    end
end

function ObjectManager:getChannel(channel_id)
    return self.cache:get("channel_" .. channel_id)
end

function ObjectManager:getGuildChannels(guild_id)
    local guild_channels = self.cache:get("guild_channels_" .. guild_id) or {}
    local channels = {}
    for channel_id in pairs(guild_channels) do
        local channel = self:getChannel(channel_id)
        if channel then
            table.insert(channels, channel)
        end
    end
    return channels
end

-- Message management
function ObjectManager:setMessage(message)
    if message and message.id then
        self.cache:set("message_" .. message.id, message, 900) -- 15 minutes
        if message.channel_id then
            -- Store recent messages per channel
            local channel_messages = self.cache:get("channel_messages_" .. message.channel_id) or {}
            table.insert(channel_messages, 1, message.id)
            -- Keep only last 50 messages per channel
            if #channel_messages > 50 then
                table.remove(channel_messages, 51)
            end
            self.cache:set("channel_messages_" .. message.channel_id, channel_messages, 900)
        end
    end
end

function ObjectManager:getMessage(message_id)
    return self.cache:get("message_" .. message_id)
end

-- Bulk operations
function ObjectManager:clearGuildData(guild_id)
    self.cache:delete("guild_" .. guild_id)
    self.cache:delete("guild_channels_" .. guild_id)
    
    -- Clear related channels
    local guild_channels = self.cache:get("guild_channels_" .. guild_id) or {}
    for channel_id in pairs(guild_channels) do
        self.cache:delete("channel_" .. channel_id)
    end
    self.cache:delete("guild_channels_" .. guild_id)
end

function ObjectManager:getStats()
    return self.cache:getStats()
end

return ObjectManager