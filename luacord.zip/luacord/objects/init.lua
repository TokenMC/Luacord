local ObjectManager = require("luacord.objects.object_manager")

return {
    ObjectManager = ObjectManager,
    create = function(cache) return ObjectManager:new(cache) end
}